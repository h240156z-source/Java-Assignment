package question1;

public class Account extends Bank {

    public Account(String accountName, double balance) {
        super(accountName, balance);
    }

    @Override
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: $" + amount);
            logTransaction(accountName + " deposited $" + amount + " | Balance: $" + balance);
        } else {
            System.out.println("Invalid deposit amount. Must be greater than 0.");
        }
    }

    @Override
    public void withdraw(double amount) {
        if (amount > balance) {
            System.out.println("Withdrawal amount exceeded account balance.");
            logTransaction(accountName + " attempted withdrawal of $" + amount + " (FAILED). Balance: $" + balance);
        } else if (amount > 0) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
            logTransaction(accountName + " withdrew $" + amount + " | Balance: $" + balance);
        } else {
            System.out.println("Invalid withdrawal amount.");
        }
    }

    @Override
    public double getBalance() {
        System.out.println("Current Balance: $" + balance);
        logTransaction(accountName + " checked balance | Balance: $" + balance);
        return balance;
    }
}